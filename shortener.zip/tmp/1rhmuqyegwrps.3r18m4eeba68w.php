<?php foreach (($result?:[]) as $item): ?>
    <span><?= ($item['link']) ?></span>
<?php endforeach; ?>